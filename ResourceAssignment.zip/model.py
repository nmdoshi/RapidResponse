from docplex.mp.model import *
from docplex.mp.utils import *
from docplex.util.status import JobSolveStatus
from docplex.mp.conflict_refiner import ConflictRefiner, VarUbConstraintWrapper, VarLbConstraintWrapper
from docplex.mp.relaxer import Relaxer
import time
import sys
import operator

import pandas as pd
import numpy as np
import math

import codecs
import sys

# Handle output of unicode strings
if sys.version_info[0] < 3:
    sys.stdout = codecs.getwriter('utf8')(sys.stdout)


# Label constraint
def helper_add_labeled_cplex_constraint(mdl, expr, label, context=None, columns=None):
    global expr_counter
    if isinstance(expr, np.bool_):
        expr = expr.item()
    if isinstance(expr, bool):
        pass  # Adding a trivial constraint: if infeasible, docplex will raise an exception it is added to the model
    else:
        expr.name = '_L_EXPR_' + str(len(expr_to_info) + 1)
        if columns:
            ctxt = ", ".join(str(getattr(context, col)) for col in columns)
        else:
            if context:
                ctxt = context.Index if isinstance(context.Index, str) is not None else ", ".join(context.Index)
            else:
                ctxt = None
        expr_to_info[expr.name] = (label, ctxt)
    mdl.add(expr)

def helper_get_column_name_for_property(property):
    return helper_property_id_to_column_names_map.get(property, 'unknown')


def helper_get_index_names_for_type(dataframe, type):
    if not is_pandas_dataframe(dataframe):
        return None
    return [name for name in dataframe.index.names if name in helper_concept_id_to_index_names_map.get(type, [])]


helper_concept_id_to_index_names_map = {
    'Parameters': ['id_of_Parameters'],
    'CityDemand': ['id_of_CityDemand'],
    'Resource': ['id_of_Resource'],
    'City': ['id_of_CityDemand'],
    'cResource': ['id_of_Resource'],
    'cActivity': ['id_of_CityDemand']}
helper_property_id_to_column_names_map = {
    'CityDemand.CITY': 'CITY',
    'Resource.Resource': 'Resource',
    'City.CITY': 'CITY',
    'CityDemand.FCST_DEMAND_1_WK': 'FCST_DEMAND_1_WK',
    'Parameters.MaxShipments': 'MaxShipments'}


# Data model definition for each table
# Data collection: list_of_City ['CITY']
# Data collection: list_of_CityDemand ['CITY', 'FCST_DEMAND_1_WK']
# Data collection: list_of_Parameters ['MaxShipments', '__line']
# Data collection: list_of_Resource ['Resource']

# Create a pandas Dataframe for each data table
list_of_City = inputs[u'City']
list_of_City = list_of_City[[u'CITY']].copy()
list_of_City.rename(columns={u'CITY': 'CITY'}, inplace=True)
list_of_CityDemand = inputs[u'CityDemand']
list_of_CityDemand = list_of_CityDemand[[u'CITY', u'FCST_DEMAND_1_WK']].copy()
list_of_CityDemand.rename(columns={u'CITY': 'CITY', u'FCST_DEMAND_1_WK': 'FCST_DEMAND_1_WK'}, inplace=True)
list_of_Parameters = inputs[u'Parameters']
list_of_Parameters = list_of_Parameters[[u'MaxShipments']].copy()
list_of_Parameters.rename(columns={u'MaxShipments': 'MaxShipments'}, inplace=True)
list_of_Resource = inputs[u'Resource']
list_of_Resource = list_of_Resource[[u'Resource']].copy()
list_of_Resource.rename(columns={u'Resource': 'Resource'}, inplace=True)

# Set index when a primary key is defined
list_of_City.set_index('CITY', inplace=True)
list_of_City.sort_index(inplace=True)
list_of_City.index.name = 'id_of_CityDemand'
list_of_CityDemand.set_index('CITY', inplace=True)
list_of_CityDemand.sort_index(inplace=True)
list_of_CityDemand.index.name = 'id_of_CityDemand'
list_of_Parameters.index.name = 'id_of_Parameters'
list_of_Resource.set_index('Resource', inplace=True)
list_of_Resource.sort_index(inplace=True)
list_of_Resource.index.name = 'id_of_Resource'


# Create data frame as cartesian product of: Resource x City
list_of_ResourceAllocation = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Resource.index, list_of_City.index), names=['id_of_Resource', 'id_of_CityDemand']))
# Create data frame as cartesian product of: Resource x City
list_of_ResourceAssignment = pd.DataFrame(index=pd.MultiIndex.from_product((list_of_Resource.index, list_of_City.index), names=['id_of_Resource', 'id_of_CityDemand']))




def build_model():
    mdl = Model()

    # Definition of model variables
    list_of_ResourceAllocation['resourceAllocationVar'] = mdl.continuous_var_list(len(list_of_ResourceAllocation))
    list_of_ResourceAssignment['resourceAssignmentVar'] = mdl.binary_var_list(len(list_of_ResourceAssignment))


    # Definition of model
    # Objective cMaximizeAssignmentsAutoSelected-
    # Combine weighted criteria: 
    # 	cMaximizeAssignmentsAutoSelected cMaximizeAssignmentsAutoSelected 1.2{
    # 	assignment = cResourceAssignment[Resource, City],
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null,
    # 	(static) numericExpr = decisionPath(cResourceAssignment[Resource, City])} with weight 5.0
    # 	cMaximizeGoalAssign cMaximizeGoalAssign 1.2{
    # 	numericExpr = decisionPath(cResourceAllocation[Resource, City]),
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null} with weight 5.0
    agg_ResourceAssignment_resourceAssignmentVar_SG1 = mdl.sum(list_of_ResourceAssignment.resourceAssignmentVar)
    agg_ResourceAllocation_resourceAllocationVar_SG2 = mdl.sum(list_of_ResourceAllocation.resourceAllocationVar)
    
    kpis_expression_list = [
        (1, 16.0, agg_ResourceAssignment_resourceAssignmentVar_SG1, 1, 0, u'the number of Resource to City assignments'),
        (1, 16.0, agg_ResourceAllocation_resourceAllocationVar_SG2, 1, 0, u'total Resource to City allocations')]
    custom_code.update_goals_list(kpis_expression_list)
    
    for _, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list:
        mdl.add_kpi(kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset), publish_name=kpi_name)
    
    mdl.maximize(sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list]))
    
    # [ST_1] Constraint : cLinkSelectionToAllocationConstraint_cIterativeRelationalConstraint
    # Synchronize assignment for Resource to City allocations
    # Label: CT_1_Synchronize_assignment_for_Resource_to_City_allocations
    join_ResourceAllocation = list_of_ResourceAllocation.reset_index().merge(list_of_ResourceAssignment.reset_index(), left_on=['id_of_Resource', 'id_of_CityDemand'], right_on=['id_of_Resource', 'id_of_CityDemand']).set_index(['id_of_Resource', 'id_of_CityDemand'])
    groupbyLevels = ['id_of_Resource', 'id_of_CityDemand']
    groupby_ResourceAllocation = join_ResourceAllocation.resourceAllocationVar.groupby(level=groupbyLevels).sum().to_frame()
    list_of_Resource_maxValueAllocation = pd.Series([100000000] * len(list_of_Resource)).to_frame('maxValueAllocation').set_index(list_of_Resource.index)
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Resource_maxValueAllocation.maxValueAllocation, how='inner')
    join_ResourceAssignment['conditioned_maxValueAllocation'] = join_ResourceAssignment.resourceAssignmentVar * join_ResourceAssignment.maxValueAllocation
    join_ResourceAllocation_2 = groupby_ResourceAllocation.reset_index().merge(join_ResourceAssignment.reset_index()[['id_of_Resource', 'id_of_CityDemand', 'conditioned_maxValueAllocation', 'resourceAssignmentVar']], left_on=['id_of_Resource', 'id_of_CityDemand'], right_on=['id_of_Resource', 'id_of_CityDemand'], how='inner').set_index(['id_of_Resource', 'id_of_CityDemand'])
    for row in join_ResourceAllocation_2.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.resourceAllocationVar <= row.conditioned_maxValueAllocation, u'Synchronize assignment for Resource to City allocations', row)
    
    # [ST_2] Constraint : cLinkSelectionToAllocationConstraint_cIterativeRelationalConstraint
    # Synchronize assignment for Resource to City allocations
    # Label: CT_2_Synchronize_assignment_for_Resource_to_City_allocations
    join_ResourceAllocation = list_of_ResourceAllocation.reset_index().merge(list_of_ResourceAssignment.reset_index(), left_on=['id_of_Resource', 'id_of_CityDemand'], right_on=['id_of_Resource', 'id_of_CityDemand']).set_index(['id_of_Resource', 'id_of_CityDemand'])
    groupbyLevels = ['id_of_Resource', 'id_of_CityDemand']
    groupby_ResourceAllocation = join_ResourceAllocation.resourceAllocationVar.groupby(level=groupbyLevels).sum().to_frame()
    list_of_Resource_minValueAllocationForAssignment = pd.Series([0.10000000149011612] * len(list_of_Resource)).to_frame('minValueAllocationForAssignment').set_index(list_of_Resource.index)
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Resource_minValueAllocationForAssignment.minValueAllocationForAssignment, how='inner')
    join_ResourceAssignment['conditioned_minValueAllocationForAssignment'] = join_ResourceAssignment.resourceAssignmentVar * join_ResourceAssignment.minValueAllocationForAssignment
    join_ResourceAllocation_2 = groupby_ResourceAllocation.reset_index().merge(join_ResourceAssignment.reset_index()[['id_of_Resource', 'id_of_CityDemand', 'conditioned_minValueAllocationForAssignment', 'resourceAssignmentVar']], left_on=['id_of_Resource', 'id_of_CityDemand'], right_on=['id_of_Resource', 'id_of_CityDemand'], how='inner').set_index(['id_of_Resource', 'id_of_CityDemand'])
    for row in join_ResourceAllocation_2.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.resourceAllocationVar >= row.conditioned_minValueAllocationForAssignment, u'Synchronize assignment for Resource to City allocations', row)
    
    # [ST_3] Constraint : cGlobalRelationalConstraint_cGlobalRelationalConstraint
    # total Resource to City allocations is less than or equal to MaxShipments of Parameters
    # Label: CT_3_total_Resource_to_City_allocations_is_less_than_or_equal_to_MaxShipments_of_Parameters
    agg_ResourceAllocation_resourceAllocationVar_lhs = mdl.sum(list_of_ResourceAllocation.resourceAllocationVar)
    helper_add_labeled_cplex_constraint(mdl, agg_ResourceAllocation_resourceAllocationVar_lhs <= list_of_Parameters.MaxShipments.iloc[0], u'total Resource to City allocations is less than or equal to MaxShipments of Parameters')
    
    # [ST_4] Constraint : cActivityRelationalConstraint_cIterativeRelationalConstraint
    # For each City, FCST_DEMAND_1_WK of CITY is greater than or equal to total allocation
    # Label: CT_4_For_each_City__FCST_DEMAND_1_WK_of_CITY_is_greater_than_or_equal_to_total_allocation
    groupbyLevels = ['id_of_CityDemand']
    groupby_ResourceAllocation = list_of_ResourceAllocation.resourceAllocationVar.groupby(level=groupbyLevels).sum().to_frame()
    join_CityDemand = list_of_CityDemand.join(groupby_ResourceAllocation.resourceAllocationVar, how='inner')
    for row in join_CityDemand[join_CityDemand.FCST_DEMAND_1_WK.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.FCST_DEMAND_1_WK >= row.resourceAllocationVar, u'For each City, FCST_DEMAND_1_WK of CITY is greater than or equal to total allocation', row)


    return mdl


def solve_model(mdl):
    mdl.parameters.timelimit = 120
    # Call to custom code to update parameters value
    custom_code.update_solver_params(mdl.parameters)
    # Update parameters value according to environment variables definition
    cplex_param_env_prefix = 'ma.cplex.'
    cplex_params = [name.qualified_name for name in mdl.parameters.generate_params()]
    for param in cplex_params:
        env_param = cplex_param_env_prefix + param
        param_value = get_environment().get_parameter(env_param)
        if param_value:
            # Updating parameter value
            print("Updated value for parameter %s = %s" % (param, param_value))
            parameters = mdl.parameters
            for p in param.split('.')[1:]:
                parameters = parameters.__getattribute__(p)
            parameters.set(param_value)

    msol = mdl.solve(log_output=True)
    if not msol:
        print("!!! Solve of the model fails")
        if mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_SOLUTION or mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_OR_UNBOUNDED_SOLUTION:
            crefiner = ConflictRefiner()
            conflicts = crefiner.refine_conflict(model, log_output=True)
            export_conflicts(conflicts)
            
    print('Solve status: %s' % mdl.get_solve_status())
    mdl.report()
    return msol


expr_to_info = {}


def export_conflicts(conflicts):
    # Display conflicts in console
    print('Conflict set:')
    list_of_conflicts = pd.DataFrame(columns=['constraint', 'context', 'detail'])
    for conflict, index in zip(conflicts, range(len(conflicts))):
        st = conflict.status
        ct = conflict.element
        label, context = expr_to_info.get(conflict.name, ('N/A', conflict.name))
        label_type = type(conflict.element)
        if isinstance(conflict.element, VarLbConstraintWrapper) \
                or isinstance(conflict.element, VarUbConstraintWrapper):
            label = 'Upper/lower bound conflict for variable: {}'.format(conflict.element._var)
            context = 'Decision variable definition'
            ct = conflict.element.get_constraint()

        # Print conflict information in console
        print("Conflict involving constraint: %s, \tfor: %s -> %s" % (label, context, ct))
        list_of_conflicts = list_of_conflicts.append({'constraint': label, 'context': str(context), 'detail': ct},
                                                     ignore_index=True)

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_conflicts'] = list_of_conflicts


def export_solution(msol):
    start_time = time.time()
    mdl = msol.model
    list_of_ResourceAllocation_solution = pd.DataFrame(index=list_of_ResourceAllocation.index)
    list_of_ResourceAllocation_solution['resourceAllocationVar'] = msol.get_values(list_of_ResourceAllocation.resourceAllocationVar.values)
    list_of_ResourceAllocation_solution = list_of_ResourceAllocation_solution.round({'resourceAllocationVar': 2})
    list_of_ResourceAssignment_solution = pd.DataFrame(index=list_of_ResourceAssignment.index)
    list_of_ResourceAssignment_solution['resourceAssignmentVar'] = msol.get_values(list_of_ResourceAssignment.resourceAssignmentVar.values)
    
    # Adding extra columns based on Solution Schema
    list_of_Resource_maxValueAllocation = pd.Series([100000000] * len(list_of_Resource)).to_frame('maxValueAllocation').set_index(list_of_Resource.index)
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Resource_maxValueAllocation.maxValueAllocation, how='inner')
    list_of_ResourceAssignment_solution['Resource maxValueAllocation'] = join_ResourceAssignment['maxValueAllocation']
    list_of_Resource_minValueAllocationForAssignment = pd.Series([0.10000000149011612] * len(list_of_Resource)).to_frame('minValueAllocationForAssignment').set_index(list_of_Resource.index)
    join_ResourceAssignment = list_of_ResourceAssignment.join(list_of_Resource_minValueAllocationForAssignment.minValueAllocationForAssignment, how='inner')
    list_of_ResourceAssignment_solution['Resource minValueAllocationForAssignment'] = join_ResourceAssignment['minValueAllocationForAssignment']
    list_of_ResourceAllocation_solution['Resource to City allocation decision'] = list_of_ResourceAllocation_solution['resourceAllocationVar']
    list_of_Resource_maxValueAllocation = pd.Series([100000000] * len(list_of_Resource)).to_frame('maxValueAllocation').set_index(list_of_Resource.index)
    join_ResourceAllocation = list_of_ResourceAllocation.join(list_of_Resource_maxValueAllocation.maxValueAllocation, how='inner')
    list_of_ResourceAllocation_solution['Resource maxValueAllocation'] = join_ResourceAllocation['maxValueAllocation']
    list_of_Resource_minValueAllocationForAssignment = pd.Series([0.10000000149011612] * len(list_of_Resource)).to_frame('minValueAllocationForAssignment').set_index(list_of_Resource.index)
    join_ResourceAllocation = list_of_ResourceAllocation.join(list_of_Resource_minValueAllocationForAssignment.minValueAllocationForAssignment, how='inner')
    list_of_ResourceAllocation_solution['Resource minValueAllocationForAssignment'] = join_ResourceAllocation['minValueAllocationForAssignment']

    # Filter rows for non-selected assignments
    list_of_ResourceAssignment_solution = list_of_ResourceAssignment_solution[list_of_ResourceAssignment_solution.resourceAssignmentVar > 0.5]

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_ResourceAssignment_solution'] = list_of_ResourceAssignment_solution[['Resource maxValueAllocation', 'Resource minValueAllocationForAssignment']].reset_index()
        outputs['list_of_ResourceAllocation_solution'] = list_of_ResourceAllocation_solution[['Resource to City allocation decision', 'Resource maxValueAllocation', 'Resource minValueAllocationForAssignment']].reset_index()
        custom_code.post_process_solution(msol, outputs)

    elapsed_time = time.time() - start_time
    print('solution export done in ' + str(elapsed_time) + ' secs')
    return


# Import custom code definition if module exists
try:
    from custom_code import CustomCode
    custom_code = CustomCode(globals())
except ImportError:
    # Create a dummy anonymous object for custom_code
    custom_code = type('', (object,), {'preprocess': (lambda *args: None),
                                       'update_goals_list': (lambda *args: None),
                                       'update_model': (lambda *args: None),
                                       'update_solver_params': (lambda *args: None),
                                       'post_process_solution': (lambda *args: None)})()

# Custom pre-process
custom_code.preprocess()

print('* building wado model')
start_time = time.time()
model = build_model()

# Model customization
custom_code.update_model(model)

elapsed_time = time.time() - start_time
print('model building done in ' + str(elapsed_time) + ' secs')

print('* running wado model')
start_time = time.time()
msol = solve_model(model)
elapsed_time = time.time() - start_time
print('model solve done in ' + str(elapsed_time) + ' secs')
if msol:
    export_solution(msol)
